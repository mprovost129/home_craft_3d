# Home Craft 3D — ROADMAP

Last updated: 2026-02-09 (America/New_York)

This roadmap is a living doc: completed items stay visible, and the next
phase is always explicit.

---

## Recently completed (2026-02-09)

### Trust & access
✅ Email verification gating across registered-only features
✅ Email → in-app notification parity (user-facing emails create Notifications)

### Marketplace mechanics
✅ Favorites & Wishlist split (single combined UX page)
✅ Free digital listing cap (SiteConfig-managed) enforced server-side
✅ Seller replies to product reviews (one reply per review in v1)

### Seller listings stability
✅ Template crash fixed: no template access to private (_underscore) attributes
✅ Seller Listings publish checklist exposed as `p.publish_ok` / `p.publish_missing`

### Digital download metrics (bundle-level)
✅ Bundle-level download counter: `Product.download_count`
✅ Paid + free downloads increment:
  - `DigitalAsset.download_count`
  - `Product.download_count` (bundle-level)
✅ Unique downloaders tracking:
  - New `ProductDownloadEvent` model (user + guest session)
  - Seller Listings shows **unique / total** for FILE products

---

## Phase 1 — Storefront credibility (DONE)
✅ Add-to-cart buttons on home cards with Stripe readiness gating (`p.can_buy`)
✅ Trending computation on home (manual override + computed fill)
✅ Trending score includes purchases + reviews + engagement events
✅ Rating on cards across home + browse + “more like this” using annotations
✅ Browse sort controls (New / Trending / Top Rated)
✅ Top Rated threshold with fallback + warning banner

## Phase 2 — Engagement signals v1 (DONE)
✅ `ProductEngagementEvent` (VIEW, ADD_TO_CART, CLICK)
✅ Throttled VIEW logging on product detail
✅ Best-effort ADD_TO_CART logging on cart add

## Phase 3 — Badge membership rules (NEXT)
- [ ] Ensure browse “🔥 Trending” badge applies only to a meaningful subset:
  - (Recommended) badge if in top N AND score > 0
- [ ] Keep badge rule consistent between home + browse

## Phase 4 — Seller analytics (UP NEXT)
- [ ] Seller analytics summary page:
  - views / clicks / add-to-cart
  - net units sold
  - downloads (unique / total)
- [ ] Time-window filters (7/30/90 days)

## Phase 5 — Messaging & moderation polish
- [ ] Staff moderation queue for reported Q&A threads/messages
- [ ] Admin tooling: remove/ban/suspend actions with audit log entries

## Phase 6 — Launch hardening
- [ ] Rate limiting / abuse controls review
- [ ] Observability and error reporting
- [ ] Backups and performance tuning

- [x] Seller Analytics Summary page (7/30/90) with engagement, sales (paid-refunded), and downloads (unique/total).
