default_app_config = "core.apps.CoreConfig"
