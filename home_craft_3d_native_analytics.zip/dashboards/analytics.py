from __future__ import annotations

from typing import Any, Dict, List

from django.db.models import Count
from django.utils import timezone

from analytics.models import AnalyticsEvent


def is_configured() -> bool:
    # Native analytics is always available if the app is installed.
    return True


def get_summary(days: int = 30) -> Dict[str, Any]:
    since = timezone.now() - timezone.timedelta(days=int(days or 30))
    qs = AnalyticsEvent.objects.filter(event_type=AnalyticsEvent.EventType.PAGEVIEW, created_at__gte=since)

    pageviews = qs.count()
    visitors = qs.values("ip_hash").exclude(ip_hash="").distinct().count()
    sessions = qs.values("session_key").exclude(session_key="").distinct().count()

    return {
        "pageviews": pageviews,
        "visitors": visitors,
        "visits": sessions,
    }


def get_top_pages(days: int = 30, limit: int = 10) -> List[Dict[str, Any]]:
    since = timezone.now() - timezone.timedelta(days=int(days or 30))
    qs = (
        AnalyticsEvent.objects.filter(event_type=AnalyticsEvent.EventType.PAGEVIEW, created_at__gte=since)
        .values("path")
        .annotate(pageviews=Count("id"), visitors=Count("ip_hash", distinct=True))
        .order_by("-pageviews")[: int(limit or 10)]
    )

    rows: List[Dict[str, Any]] = []
    for r in qs:
        rows.append({"page": r["path"], "pageviews": r["pageviews"], "visitors": r["visitors"]})
    return rows
