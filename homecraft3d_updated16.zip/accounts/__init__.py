"""Accounts app.

Django 5.x does not require `default_app_config`. The preferred approach is to
set `"accounts.apps.AccountsConfig"` in `INSTALLED_APPS`.

Keeping this file intentionally minimal.
"""