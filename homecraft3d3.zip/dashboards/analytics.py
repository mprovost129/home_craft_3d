# dashboards/analytics.py
from __future__ import annotations

from typing import Any, Dict, List

from .analytics_google import get_summary as ga_get_summary
from .analytics_google import get_top_pages as ga_get_top_pages
from .analytics_google import is_configured as ga_is_configured


def is_configured() -> bool:
    return ga_is_configured()


def get_summary(days: int = 30) -> Dict[str, Any]:
    return ga_get_summary(days=days)


def get_top_pages(days: int = 30, limit: int = 10) -> List[Dict[str, Any]]:
    return ga_get_top_pages(days=days, limit=limit)
